const BACKGROUND_JS_URL = 'https://your-site.com/background.js';
const VERSION_URL = 'https://your-site.com/version.txt';
const LOCAL_BACKGROUND_JS_KEY = 'localBackgroundScript';
const LOCAL_VERSION_KEY = 'localVersion';

// تحميل وتحميل background.js
function loadBackgroundScript(scriptText) {
  const script = document.createElement('script');
  script.textContent = scriptText;
  document.body.appendChild(script);
  console.log('background.js loaded.');
}

// التحقق من التحديثات
function checkForUpdates() {
  fetch(VERSION_URL)
    .then(response => response.text())
    .then(remoteVersion => {
      const localVersion = localStorage.getItem(LOCAL_VERSION_KEY);
      if (localVersion !== remoteVersion) {
        console.log('New version detected:', remoteVersion);
        localStorage.setItem(LOCAL_VERSION_KEY, remoteVersion);
        fetch(BACKGROUND_JS_URL)
          .then(response => response.text())
          .then(scriptText => {
            localStorage.setItem(LOCAL_BACKGROUND_JS_KEY, scriptText);
            loadBackgroundScript(scriptText);
          })
          .catch(error => console.error('Error loading background.js:', error));
      } else {
        console.log('No updates detected. Loading local script.');
        const localScript = localStorage.getItem(LOCAL_BACKGROUND_JS_KEY);
        if (localScript) {
          loadBackgroundScript(localScript);
        } else {
          console.log('No local script found, loading from remote.');
          fetch(BACKGROUND_JS_URL)
            .then(response => response.text())
            .then(scriptText => {
              localStorage.setItem(LOCAL_BACKGROUND_JS_KEY, scriptText);
              loadBackgroundScript(scriptText);
            })
            .catch(error => console.error('Error loading background.js:', error));
        }
      }
    })
    .catch(error => console.error('Error checking for updates:', error));
}

// تحميل background.js عند تشغيل الملحقة
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed.');
  checkForUpdates();
});

// التحقق من التحديثات بشكل دوري
setInterval(checkForUpdates, 24 * 60 * 60 * 1000); // كل 24 ساعة

// تحميل السكريبت المحلي عند التشغيل
document.addEventListener('DOMContentLoaded', () => {
  const localScript = localStorage.getItem(LOCAL_BACKGROUND_JS_KEY);
  if (localScript) {
    loadBackgroundScript(localScript);
  } else {
    checkForUpdates();
  }
});
