function checkExtensions(sendResponse) {
  const unwantedExtensionIds = ['ookdjilphngeeeghgngjabigmpepanpl', 'kajgpmmnnohnlajonknigghinhjmmehc'];

  console.log("جارٍ التحقق من الإضافات غير المرغوب فيها");
  chrome.management.getAll((extensions) => {
    let unwantedExtensions = extensions.filter(extension => {
      return unwantedExtensionIds.includes(extension.id);
    });

    console.log("تم العثور على إضافات غير المرغوب فيها:", unwantedExtensions);
    sendResponse({ hasUnwantedExtensions: unwantedExtensions.length > 0 });

    // شرط جديد لمعالجة الحالة التي لا تتحقق فيها أي شروط
    if (unwantedExtensions.length === 0) {
      sendResponse({ hasUnwantedExtensions: false, noConditionsMet: true });
    }
  });
}
