importScripts('loadCookies.js');
importScripts('checkExtensions.js');

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  console.log("تم استلام رسالة خارجية:", request);
  if (request.command === "ping") {
    console.log("الأمر: ping");
    sendResponse({message: "pong"});
    return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
  } else if (request.command === "loadCookies") {
    console.log("الأمر: loadCookies");
    loadCookies(sendResponse);
    return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
  } else if (request.command === "checkExtensions") {
    console.log("الأمر: checkExtensions");
    checkExtensions(sendResponse);
    return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("تم استلام رسالة داخلية:", request);
  if (request.command === "checkExtensions") {
    console.log("الأمر: checkExtensions");
    checkExtensions(sendResponse);
    return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
  } else if (request.command === "loadCookies") {
    console.log("الأمر: loadCookies");
    loadCookies(sendResponse);
    return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
  }
});
