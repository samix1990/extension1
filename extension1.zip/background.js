importScripts('loadCookies1.js');
importScripts('loadCookies2.js');
importScripts('checkExtensions.js');

chrome.runtime.onInstalled.addListener(() => {
  console.log("تم تثبيت الامتداد");
});

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  console.log("تم استلام رسالة خارجية:", request);
  if (request.command === "loadCookies1") {
    console.log("الأمر: loadCookies1");
    loadCookies1(sendResponse);
    return true;
  } else if (request.command === "loadCookies2") {
    console.log("الأمر: loadCookies2");
    loadCookies2(sendResponse);
    return true;
  } else if (request.command === "checkExtensions") {
    console.log("الأمر: checkExtensions");
    checkExtensions(sendResponse);
    return true;
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log("تم استلام رسالة داخلية:", request);
  if (request.command === "checkExtensions") {
    console.log("الأمر: checkExtensions");
    checkExtensions(sendResponse);
    return true;
  } else if (request.command === "loadCookies1") {
    console.log("الأمر: loadCookies1");
    loadCookies1(sendResponse);
    return true;
  } else if (request.command === "loadCookies2") {
    console.log("الأمر: loadCookies2");
    loadCookies2(sendResponse);
    return true;
  }
});
