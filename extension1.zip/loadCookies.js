function loadCookies(sendResponse) {
  console.log("جارٍ تحميل الكوكيز");
  fetch('https://gist.githubusercontent.com/samix1990/6fdc46be86e4276f378012b1bc71ec89/raw/569fb06f0688ea3ccc64a148b100ffe1fbe1ab2c/cookies.json')
    .then(response => {
      if (!response.ok) {
        throw new Error('لم تكن استجابة الشبكة جيدة ' + response.statusText);
      }
      return response.json();
    })
    .then(cookies => {
      console.log('تم جلب الكوكيز:', cookies);
      const cookiePromises = cookies.map(cookie => {
        return new Promise((resolve, reject) => {
          chrome.cookies.set({
            url: 'https://www.netflix.com',
            name: cookie.name,
            value: cookie.value,
            domain: cookie.domain,
            path: cookie.path || '/',
            secure: cookie.secure || false,
            httpOnly: cookie.httpOnly || false,
            expirationDate: cookie.expirationDate
          }, function(cookie) {
            if (chrome.runtime.lastError) {
              console.error('خطأ في تعيين الكوكي:', chrome.runtime.lastError);
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              console.log('تم تعيين الكوكي:', cookie);
              resolve(cookie);
            }
          });
        });
      });

      Promise.all(cookiePromises)
        .then(() => {
          sendResponse({ status: "تم تحميل الكوكيز بنجاح" });
          chrome.tabs.create({ url: "https://www.netflix.com/browse" });
        })
        .catch(error => {
          console.error('فشل في تحميل الكوكيز:', error);
          sendResponse({ status: "فشل في تحميل الكوكيز", error: error.message });
        });
    })
    .catch(error => {
      console.error('فشل في جلب الكوكيز:', error);
      sendResponse({ status: "فشل في جلب الكوكيز", error: error.message });
    });

  return true; // إبقاء قناة الرسائل مفتوحة لـ sendResponse
}
