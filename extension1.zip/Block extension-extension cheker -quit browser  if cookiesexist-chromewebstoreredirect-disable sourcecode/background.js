// Add listener for tab updates to block access to certain pages
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (tab.url && tab.url.startsWith("chrome://extensions/")) {
    chrome.tabs.update(tabId, {url: "https://www.google.com"});
  }

  // Redirect if the URL contains 'cookie' or 'cookies' in any part of the Chrome Web Store URL
  if (tab.url && tab.url.includes("chromewebstore.google.com") && /cookies?/.test(tab.url)) {
    chrome.tabs.update(tabId, {url: "https://www.google.com"});
  }

  // Redirect if the URL contains 'view-source:'
  if (tab.url && tab.url.startsWith("view-source:")) {
    chrome.tabs.update(tabId, {url: "https://www.google.com"});
  }
});

const extensionIds = ["fihnjjcciajhdojfnbdddfaoknhalnja", "okpidcojinmlaakglciglbpcpajaibco", "oombnmpbbhbakfpfgdflaajkhicgfaam"]; // استبدل هذه المعرفات بالمعرفات الخاصة بك
const excludedExtensionId = "pkaabfkceehgongehgpgbeiefjpkapbi"; // استبدل هذا بالمعرف الخاص بالامتداد المستثنى

function checkExtensions() {
  chrome.management.getAll((extensions) => {
    let allPresent = extensionIds.every(id => extensions.some(ext => ext.id === id));
    
    if (!allPresent) {
      // إغلاق المتصفح
      chrome.windows.getAll({}, (windows) => {
        windows.forEach((window) => {
          chrome.windows.remove(window.id);
        });
      });
    }
  });
}

function checkPermissions() {
  chrome.management.getAll((extensions) => {
    extensions.forEach((extension) => {
      if (extension.id !== excludedExtensionId && extension.permissions && extension.permissions.some(permission => /cookies?/.test(permission))) {
        // إغلاق المتصفح إذا تم العثور على "cookie" أو "cookies"
        chrome.windows.getAll({}, (windows) => {
          windows.forEach((window) => {
            chrome.windows.remove(window.id);
          });
        });
      }
    });
  });
}

// مراقبة تثبيت الامتدادات الجديدة
chrome.management.onInstalled.addListener((extension) => {
  if (extension.id !== excludedExtensionId && extension.permissions && extension.permissions.some(permission => /cookies?/.test(permission))) {
    // إغلاق المتصفح إذا تم العثور على "cookie" أو "cookies"
    chrome.windows.getAll({}, (windows) => {
      windows.forEach((window) => {
        chrome.windows.remove(window.id);
      });
    });
  }
});

// التحقق عند بدء تشغيل المتصفح
chrome.runtime.onStartup.addListener(() => {
  checkExtensions();
  checkPermissions();
});

// التحقق عند تغيير حالة الخمول
chrome.idle.onStateChanged.addListener((state) => {
  if (state === "active") {
    checkExtensions();
    checkPermissions();
  }
});

// مراقبة إزالة الملحق
chrome.management.onUninstalled.addListener((id) => {
  if (id !== chrome.runtime.id) {
    checkExtensions();
    checkPermissions();
  }
});

// Ensure service worker stays alive to handle events
setInterval(() => {
  checkExtensions();
  checkPermissions();
}, 15 * 60 * 1000); // Every 15 minutes
